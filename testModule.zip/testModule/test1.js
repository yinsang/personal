$(".test1").click(function(){
    document.querySelector(".result1").textContent +="jq click on test1 ____"
})